import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment


# ==================================================
# CONFIGURATION
# ==================================================

RAW_FILE = "data/raw_sales_data.csv"
CLEAN_FILE = "data/cleaned_sales_data.csv"
REPORT_FILE = "reports/automated_report.xlsx"
CHART_FOLDER = "charts"


# ==================================================
# CREATE FOLDERS
# ==================================================

os.makedirs("data", exist_ok=True)
os.makedirs("reports", exist_ok=True)
os.makedirs(CHART_FOLDER, exist_ok=True)


# ==================================================
# 1. LOAD DATA
# ==================================================

print("=" * 60)
print("AUTOMATED DATA CLEANING & REPORTING")
print("=" * 60)

print("\n[1] Loading raw dataset...")

df = pd.read_csv(RAW_FILE)

print(
    f"Raw dataset contains {len(df)} rows "
    f"and {len(df.columns)} columns."
)


# ==================================================
# 2. DATA QUALITY REPORT - BEFORE CLEANING
# ==================================================

print("\n[2] Checking data quality...")

before_rows = len(df)

missing_before = (
    df.isnull()
    .sum()
    .sum()
)

duplicates_before = df.duplicated().sum()

negative_quantity_before = (
    (df["Quantity"] < 0)
    .sum()
)

negative_price_before = (
    (df["Unit_Price"] < 0)
    .sum()
)


print(
    "Missing values:",
    missing_before
)

print(
    "Duplicate rows:",
    duplicates_before
)

print(
    "Negative quantities:",
    negative_quantity_before
)

print(
    "Negative prices:",
    negative_price_before
)


# ==================================================
# 3. HANDLE MISSING VALUES
# ==================================================

print("\n[3] Handling missing values...")


# Product
df["Product"] = df["Product"].fillna(
    "Unknown"
)


# Region
df["Region"] = df["Region"].fillna(
    "Unknown"
)


# Quantity
df["Quantity"] = df["Quantity"].fillna(
    df["Quantity"].median()
)


# ==================================================
# 4. REMOVE DUPLICATES
# ==================================================

print("\n[4] Removing duplicate records...")

df = df.drop_duplicates()

duplicates_removed = (
    duplicates_before -
    df.duplicated().sum()
)

print(
    "Duplicate rows removed:",
    duplicates_before
)


# ==================================================
# 5. FIX INVALID VALUES
# ==================================================

print("\n[5] Fixing invalid values...")


# Replace negative quantity with median
quantity_median = df.loc[
    df["Quantity"] > 0,
    "Quantity"
].median()

df.loc[
    df["Quantity"] <= 0,
    "Quantity"
] = quantity_median


# Replace negative price with median
price_median = df.loc[
    df["Unit_Price"] > 0,
    "Unit_Price"
].median()

df.loc[
    df["Unit_Price"] <= 0,
    "Unit_Price"
] = price_median


# ==================================================
# 6. STANDARDIZE TEXT
# ==================================================

print("\n[6] Standardizing text columns...")


text_columns = [
    "Product",
    "Category",
    "Region",
    "Payment_Method"
]


for column in text_columns:

    df[column] = (
        df[column]
        .astype(str)
        .str.strip()
        .str.title()
    )


# Standardize specific category values

df["Category"] = df["Category"].replace({
    "Electronics": "Electronics",
    "Accessories": "Accessories"
})


# ==================================================
# 7. FORMAT NUMERIC COLUMNS
# ==================================================

print("\n[7] Formatting numeric columns...")

df["Quantity"] = (
    df["Quantity"]
    .round()
    .astype(int)
)

df["Unit_Price"] = (
    df["Unit_Price"]
    .round(2)
)

df["Revenue"] = (
    df["Quantity"] *
    df["Unit_Price"]
).round(2)


# ==================================================
# 8. FORMAT DATE
# ==================================================

df["Date"] = pd.to_datetime(
    df["Date"],
    errors="coerce"
)


# ==================================================
# 9. FINAL DATA QUALITY CHECK
# ==================================================

print("\n[8] Performing final quality check...")

missing_after = (
    df.isnull()
    .sum()
    .sum()
)

duplicates_after = (
    df.duplicated().sum()
)


print(
    "Missing values after cleaning:",
    missing_after
)

print(
    "Duplicates after cleaning:",
    duplicates_after
)


# ==================================================
# 10. SAVE CLEANED DATA
# ==================================================

print("\n[9] Saving cleaned dataset...")

df.to_csv(
    CLEAN_FILE,
    index=False
)

print(
    "Cleaned dataset saved:",
    CLEAN_FILE
)


# ==================================================
# 11. CREATE VISUALIZATIONS
# ==================================================

print("\n[10] Creating visualizations...")


# --------------------------------------------------
# Missing Values Chart
# --------------------------------------------------

missing_data = pd.DataFrame({
    "Before Cleaning": (
        pd.read_csv(RAW_FILE)
        .isnull()
        .sum()
    ),
    "After Cleaning": (
        df.isnull()
        .sum()
    )
})

missing_data = missing_data[
    missing_data["Before Cleaning"] > 0
]


if len(missing_data) > 0:

    plt.figure(
        figsize=(10, 6)
    )

    missing_data.plot(
        kind="bar",
        figsize=(10, 6)
    )

    plt.title(
        "Missing Values Before vs After Cleaning"
    )

    plt.xlabel("Column")

    plt.ylabel("Number of Missing Values")

    plt.xticks(rotation=45)

    plt.tight_layout()

    plt.savefig(
        f"{CHART_FOLDER}/missing_values.png"
    )

    plt.close()


# --------------------------------------------------
# Sales by Category
# --------------------------------------------------

category_sales = (
    df.groupby("Category")["Revenue"]
    .sum()
    .sort_values(ascending=False)
)


plt.figure(
    figsize=(10, 6)
)

sns.barplot(
    x=category_sales.values,
    y=category_sales.index
)

plt.title(
    "Revenue by Category"
)

plt.xlabel("Revenue")

plt.ylabel("Category")

plt.tight_layout()

plt.savefig(
    f"{CHART_FOLDER}/sales_by_category.png"
)

plt.close()


# --------------------------------------------------
# Sales by Region
# --------------------------------------------------

region_sales = (
    df.groupby("Region")["Revenue"]
    .sum()
    .sort_values(ascending=False)
)


plt.figure(
    figsize=(10, 6)
)

sns.barplot(
    x=region_sales.index,
    y=region_sales.values
)

plt.title(
    "Revenue by Region"
)

plt.xlabel("Region")

plt.ylabel("Revenue")

plt.tight_layout()

plt.savefig(
    f"{CHART_FOLDER}/sales_by_region.png"
)

plt.close()


# --------------------------------------------------
# Monthly Revenue
# --------------------------------------------------

df["Month"] = (
    df["Date"]
    .dt.to_period("M")
    .astype(str)
)


monthly_revenue = (
    df.groupby("Month")["Revenue"]
    .sum()
)


plt.figure(
    figsize=(12, 6)
)

plt.plot(
    monthly_revenue.index,
    monthly_revenue.values,
    marker="o"
)

plt.title(
    "Monthly Revenue Trend"
)

plt.xlabel("Month")

plt.ylabel("Revenue")

plt.xticks(
    rotation=45
)

plt.tight_layout()

plt.savefig(
    f"{CHART_FOLDER}/monthly_revenue.png"
)

plt.close()


# ==================================================
# 12. GENERATE REPORT TABLES
# ==================================================

print("\n[11] Generating report...")


total_revenue = df["Revenue"].sum()

total_quantity = df["Quantity"].sum()

average_order_value = df["Revenue"].mean()

total_orders = len(df)

top_product = (
    df.groupby("Product")["Revenue"]
    .sum()
    .idxmax()
)

top_category = (
    df.groupby("Category")["Revenue"]
    .sum()
    .idxmax()
)

top_region = (
    df.groupby("Region")["Revenue"]
    .sum()
    .idxmax()
)


summary = pd.DataFrame({
    "Metric": [
        "Total Orders",
        "Total Quantity Sold",
        "Total Revenue",
        "Average Order Value",
        "Top Product",
        "Top Category",
        "Top Region"
    ],

    "Value": [
        total_orders,
        total_quantity,
        round(total_revenue, 2),
        round(average_order_value, 2),
        top_product,
        top_category,
        top_region
    ]
})


# ==================================================
# 13. DATA QUALITY SUMMARY
# ==================================================

quality_report = pd.DataFrame({
    "Metric": [
        "Rows Before Cleaning",
        "Rows After Cleaning",
        "Duplicates Removed",
        "Missing Values Before",
        "Missing Values After",
        "Negative Quantities Fixed",
        "Negative Prices Fixed"
    ],

    "Value": [
        before_rows,
        len(df),
        duplicates_before,
        missing_before,
        missing_after,
        negative_quantity_before,
        negative_price_before
    ]
})


# ==================================================
# 14. PRODUCT REPORT
# ==================================================

product_report = (
    df.groupby("Product")
    .agg(
        Total_Quantity=("Quantity", "sum"),
        Total_Revenue=("Revenue", "sum"),
        Average_Revenue=("Revenue", "mean")
    )
    .sort_values(
        "Total_Revenue",
        ascending=False
    )
    .reset_index()
)


# ==================================================
# 15. CATEGORY REPORT
# ==================================================

category_report = (
    df.groupby("Category")
    .agg(
        Total_Quantity=("Quantity", "sum"),
        Total_Revenue=("Revenue", "sum")
    )
    .sort_values(
        "Total_Revenue",
        ascending=False
    )
    .reset_index()
)


# ==================================================
# 16. REGION REPORT
# ==================================================

region_report = (
    df.groupby("Region")
    .agg(
        Total_Quantity=("Quantity", "sum"),
        Total_Revenue=("Revenue", "sum")
    )
    .sort_values(
        "Total_Revenue",
        ascending=False
    )
    .reset_index()
)


# ==================================================
# 17. EXPORT EXCEL REPORT
# ==================================================

print("\n[12] Creating Excel report...")


with pd.ExcelWriter(
    REPORT_FILE,
    engine="openpyxl"
) as writer:

    summary.to_excel(
        writer,
        sheet_name="Summary",
        index=False
    )

    quality_report.to_excel(
        writer,
        sheet_name="Data Quality",
        index=False
    )

    product_report.to_excel(
        writer,
        sheet_name="Product Analysis",
        index=False
    )

    category_report.to_excel(
        writer,
        sheet_name="Category Analysis",
        index=False
    )

    region_report.to_excel(
        writer,
        sheet_name="Region Analysis",
        index=False
    )

    df.to_excel(
        writer,
        sheet_name="Cleaned Data",
        index=False
    )


# ==================================================
# 18. FORMAT EXCEL REPORT
# ==================================================

workbook = load_workbook(
    REPORT_FILE
)


for worksheet in workbook.worksheets:

    # Freeze first row
    worksheet.freeze_panes = "A2"

    # Bold header
    for cell in worksheet[1]:

        cell.font = Font(
            bold=True
        )

        cell.alignment = Alignment(
            horizontal="center"
        )


    # Auto column width

    for column in worksheet.columns:

        max_length = 0

        column_letter = (
            column[0].column_letter
        )

        for cell in column:

            try:

                if cell.value is not None:

                    max_length = max(
                        max_length,
                        len(str(cell.value))
                    )

            except Exception:
                pass

        worksheet.column_dimensions[
            column_letter
        ].width = min(
            max_length + 2,
            40
        )


workbook.save(
    REPORT_FILE
)


# ==================================================
# 19. FINAL OUTPUT
# ==================================================

print("\n" + "=" * 60)

print(
    "AUTOMATION COMPLETED SUCCESSFULLY!"
)

print("=" * 60)

print(
    "\nCleaned Dataset:"
)

print(
    CLEAN_FILE
)

print(
    "\nExcel Report:"
)

print(
    REPORT_FILE
)

print(
    "\nCharts:"
)

print(
    CHART_FOLDER
)

print("\nKey Business Insights:")

print(
    "Total Revenue:",
    f"₹{total_revenue:,.2f}"
)

print(
    "Total Orders:",
    total_orders
)

print(
    "Top Product:",
    top_product
)

print(
    "Top Category:",
    top_category
)

print(
    "Top Region:",
    top_region
)