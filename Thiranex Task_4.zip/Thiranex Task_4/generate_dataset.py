import pandas as pd
import numpy as np
import os

np.random.seed(42)

products = [
    "Laptop",
    "Smartphone",
    "Tablet",
    "Headphones",
    "Keyboard",
    "Mouse"
]

categories = [
    "Electronics",
    "electronics",
    "ELECTRONICS",
    "Accessories",
    "accessories",
    "Accessories "
]

regions = [
    "North",
    "South",
    "East",
    "West",
    "north",
    "south",
    "WEST "
]

payment_methods = [
    "UPI",
    "Credit Card",
    "Debit Card",
    "Cash",
    "upi",
    "credit card",
    "UPI "
]

n = 500

df = pd.DataFrame({
    "Order_ID": range(1001, 1001 + n),

    "Date": pd.date_range(
        "2025-01-01",
        "2025-12-31",
        periods=n
    ),

    "Product": np.random.choice(
        products,
        n
    ),

    "Category": np.random.choice(
        categories,
        n
    ),

    "Region": np.random.choice(
        regions,
        n
    ),

    "Quantity": np.random.randint(
        1,
        10,
        n
    ),

    "Unit_Price": np.random.randint(
        500,
        80000,
        n
    ),

    "Payment_Method": np.random.choice(
        payment_methods,
        n
    )
})


# Calculate revenue
df["Revenue"] = (
    df["Quantity"] *
    df["Unit_Price"]
)


# --------------------------------------------------
# Add Missing Values
# --------------------------------------------------

missing_indexes = np.random.choice(
    df.index,
    20,
    replace=False
)

df.loc[
    missing_indexes[:7],
    "Product"
] = np.nan

df.loc[
    missing_indexes[7:14],
    "Region"
] = np.nan

df.loc[
    missing_indexes[14:],
    "Quantity"
] = np.nan


# --------------------------------------------------
# Add Invalid Values
# --------------------------------------------------

df.loc[20, "Quantity"] = -5
df.loc[21, "Unit_Price"] = -1000


# --------------------------------------------------
# Add Duplicate Rows
# --------------------------------------------------

duplicates = df.iloc[30:40].copy()

df = pd.concat(
    [df, duplicates],
    ignore_index=True
)


# --------------------------------------------------
# Save Raw Dataset
# --------------------------------------------------

os.makedirs("data", exist_ok=True)

df.to_csv(
    "data/raw_sales_data.csv",
    index=False
)

print("Raw dataset created successfully!")

print(
    "File: data/raw_sales_data.csv"
)

print(
    "Number of rows:",
    len(df)
)

print("\nSample data:")
print(df.head())